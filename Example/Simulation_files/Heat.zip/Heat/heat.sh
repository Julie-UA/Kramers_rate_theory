#!/usr/bin/env bash


# Heat 1
cat > 03-heat-1.inp<<EOF
Heat 1
&cntrl
	imin=0,
	nstlim=8000,       ! 8000 steps of 0.002 ps = 16
	dt=0.002,
	irest=0,
	ig=-1,
	ntx=1,
	ntc=2,
	ntf=2,
	cut=8.0,
	ntpr=1000,
	ntwx=0,
	ntwr=0,
	ntt=1,
	temp0=10.0,
	tempi=10.0,
	ntb=2,              ! Constant pressure periodic boundary conditions
	ntp=1,              ! MD with isotropic position scaling (constant pressure)
	barostat=1,         ! Berensen barostat
	pres0=1,
	taup=2.0,
/
EOF
pmemd.cuda \
	-O \
	-i   03-heat-1.inp \
	-o   03-heat-1.out \
	-p   ../complex.solvated.prmtop \
	-c   ../E_min/02-min.ncrst \
	-r   03-heat-1.ncrst \
	-x   03-heat-1.nc \
	-inf 03-heat-1.mdinfo


for CYCLE in 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 ; do
PREVIOUS=$((CYCLE-1))
TEMP=$((CYCLE*10))

cat > 03-heat-${CYCLE}.inp<<EOF
Heat cycle ${CYCLE}
&cntrl
	imin=0,
	nstlim=50000,       ! 50.000 steps of 0.002 ps = 100 ps
	dt=0.002,
	irest=0,
	ig=-1,
	ntx=1,
	ntc=2,
	ntf=2,
	cut=8.0,
	ntpr=1000,
	ntwx=0,
	ntwr=0,
	ntt=1,
	temp0=${TEMP},
	tempi=${TEMP},
	ntb=2,              ! Constant pressure periodic boundary conditions
	ntp=1,              ! MD with isotropic position scaling (constant pressure)
	barostat=1,         ! Berensen barostat
	pres0=1,
	taup=2.0,
/
EOF
pmemd.cuda \
	-O \
	-i   03-heat-${CYCLE}.inp \
	-o   03-heat-${CYCLE}.out \
	-p   ../complex.solvated.prmtop \
	-c   03-heat-${PREVIOUS}.ncrst \
	-r   03-heat-${CYCLE}.ncrst \
	-x   03-heat-${CYCLE}.nc \
	-inf 03-heat-${CYCLE}.mdinfo

done

cat > 03-heat.inp<<EOF
Heat
&cntrl
	imin=0,
	nstlim=50000,
	dt=0.002,
	irest=0,
	ig=-1,
	ntx=1,
	ntc=2,
	ntf=2,
	cut=8.0,
	ntpr=1000,
	ntwx=0,
	ntwr=0,
	ntt=1,
	temp0=300,
	tempi=300,
	ntb=2,              ! Constant pressure periodic boundary conditions
	ntp=1,              ! MD with isotropic position scaling (constant pressure)
	barostat=1,         ! Berensen barostat
	pres0=1,
	taup=2.0,
/
EOF
pmemd.cuda \
	-O \
	-i   03-heat.inp \
	-o   03-heat.out \
	-p   ../complex.solvated.prmtop \
	-c   03-heat-${CYCLE}.ncrst \
	-r   03-heat.ncrst \
	-x   03-heat.nc \
	-inf 03-heat.mdinfo



# PDB 
cpptraj -p ../complex.solvated.prmtop -y 03-heat.ncrst -x 03-heat.pdb -xa PDB

cat > cpptraj.inp<<EOF
parm ../../complex.solvated.prmtop
reference ../../E_Min/02-min.ncrst [MINIMIZED] 
trajin 03-heat.ncrst
align :1-223@CA ref [MINIMIZED]
autoimage
strip :WAT,Cl-,K+,Na+ outprefix stripped
trajout 03-heat.stripped.pdb
EOF
cpptraj -i cpptraj.inp


# Cleanup
for CYCLE in 2 3 4 5 6 7 8 9 11 12 13 14 15 16 17 18 19 21 22 23 24 25 26 27 28 29; do /bin/rm 03-heat-${CYCLE}.*; done

