#!/bin/bash

cat > 02-min.inp<<EOF
Minimize
&cntrl
	imin=1,
	ntx=1,
	irest=0,
	maxcyc=20000,
	ncyc=20000,
	ntpr=100,
	ntwx=0,
	cut=8.0,
/
EOF
mpirun -np 8 sander.MPI \
	-O \
	-i 02-min.inp \
	-o 02-min.out \
	-p ../complex.solvated.prmtop \
	-c ../complex.solvated.inpcrd \
	-r 02-min.ncrst \
	-inf 02-min.mdinfo

cpptraj -p ../complex.solvated.prmtop \
	-y 02-min.ncrst \
	-x 02-min.pdb \
	-xa PDB


cat > cpptraj.inp<<EOF
parm complex.solvated.prmtop
trajin 02-min.ncrst
strip :WAT,Cl-,K+,Na+ outprefix stripped
trajout 02-min.stripped.pdb
EOF
cpptraj -i cpptraj.inp

rm -f cpptraj.inp

