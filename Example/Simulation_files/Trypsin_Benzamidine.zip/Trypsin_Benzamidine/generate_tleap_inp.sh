#!/usr/bin/env bash

# Description:
# This script automatically generates a tleap input file (tleap.inp)
# including all ligands from LIG_224.pdb to LIG_693.pdb
# along with protein.pdb and calcium.pdb.

# === PARAMETERS ===
PROTEIN_PDB="../protein.pdb"
CALCIUM_PDB="../calcium.pdb"
LIGAND_DIR="../Ligands"
LIGAND_PREFIX="LIG_"
LIG_START=224
LIG_END=224
PARAM_FILE="../Ligands/LIG_693.frcmod"

# === GENERATE tleap.inp ===
cat > tleap.inp <<EOF
# Auto-generated tleap input file
source leaprc.protein.ff14SB
source leaprc.water.tip3p
source leaprc.gaff2

# Protein
protein = loadpdb ${PROTEIN_PDB}

# Calcium
calcium = loadpdb ${CALCIUM_PDB}

EOF

# Loop to load all ligands
for ((i=${LIG_START}; i<=${LIG_END}; i++)); do
  echo "loadamberparams ${LIGAND_DIR}/${LIGAND_PREFIX}${i}.frcmod" >> tleap.inp
  echo "${LIGAND_PREFIX}${i} = loadmol2 ${LIGAND_DIR}/${LIGAND_PREFIX}${i}.mol2" >> tleap.inp
done

# Combine all parts
echo "" >> tleap.inp
echo "# Make complex" >> tleap.inp
echo -n "complex = combine { protein calcium" >> tleap.inp
for ((i=${LIG_START}; i<=${LIG_END}; i++)); do
  echo " ${LIGAND_PREFIX}${i}" >> tleap.inp
done
echo " }" >> tleap.inp

# Solvation, neutralization, and saving
cat >> tleap.inp <<EOF

# Solvate and neutralize
solvateBox complex TIP3PBOX 0.1
addIonsRand complex Cl- 9
charge complex

# Add ions to 150 mM concentration
addIonsRand complex Cl- 18
addIonsRand complex Na+ 18
charge complex

check complex 
# Save outputs
saveAmberParm complex complex.solvated.prmtop complex.solvated.inpcrd
savePdb complex complex.solvated.pdb

quit
EOF

# Run tleap
echo "Running tleap..."
tleap -f tleap.inp

