#!/usr/bin/env bash


cat > NVT_eq.inp<<EOF
NVT_eq
&cntrl
	imin=0,
	nstlim=500000,   ! 500.000 steps of 0.002 ps = 1 ns
	dt=0.002,
	irest=0,
	ig=-1,
	ntx=1,
	ntc=2,
	ntf=2,
	cut=8.0,
	ntpr=10000,
	ntwx=0,
	ntwr=0,
	ntt=1,
	temp0=300.0,
	tempi=300.0,
	ntb=1,              
	ntp=0,              ! MD with isotropic position scaling (constant pressure)
	barostat=1,         ! Berensen barostat
	pres0=1,
	tautp=1.0,
/
EOF
pmemd.cuda \
	-O \
	-i   NVT_eq.inp \
	-o   NVT_eq.out \
	-p   ../complex.solvated.prmtop \
	-c   ../Heat/03-heat.ncrst \
	-r   NVT_eq.ncrst \
	-x   NVT_eq.nc \
	-inf NVT_eq.mdinfo



# PDB
cpptraj -p ../complex.solvated.prmtop -y NVT_eq.ncrst -x NVT_eq.pdb -xa PDB

cat > cpptraj.inp<<EOF
parm ../complex.solvated.prmtop
reference ../E_Min/02-min.ncrst [MINIMIZED] 
trajin NVT_eq.ncrst
align :1-223@CA ref [MINIMIZED]
autoimage
strip :WAT,Cl-,K+,Na+ outprefix stripped
trajout NVT_eq.stripped.pdb
EOF
cpptraj -i cpptraj.inp



