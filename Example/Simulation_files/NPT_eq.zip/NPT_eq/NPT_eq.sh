#!/usr/bin/env bash


cat > NPT_eq.inp<<EOF
NPT_eq
&cntrl
	imin=0,
	nstlim=500000,    ! 500.000 steps of 0.002 ps = 1 ns 
	dt=0.002,
	irest=1,
	ig=-1,
	ntx=5,
	ntc=2,
	ntf=2,
	cut=8.0,
	ntpr=10000,
	ntwx=10000,
	ntwr=10000,
	ntwv=-1,
	ntt=1,
	temp0=300.0,
	ntb=2,              
	ntp=1,              
	barostat=1,         
	pres0=1,
	tautp=1.0,
	taup=2.0,
/
EOF
pmemd.cuda \
	-O \
	-i   NPT_eq.inp \
	-o   NPT_eq.out \
	-p   ../complex.solvated.prmtop \
	-c   ../NVT_eq/NVT_eq.ncrst \
	-r   NPT_eq.ncrst \
	-x   NPT_eq.nc \
	-inf NPT_eq.mdinfo



# PDB
cpptraj -p ../complex.solvated.prmtop -y NPT_eq.ncrst -x NPT_eq.pdb -xa PDB

cat > cpptraj.inp<<EOF
parm ../complex.solvated.prmtop
reference ../NVT_eq/NVT_eq.ncrst [MINIMIZED] 
trajin NPT_eq.ncrst
align :1-223@CA ref [MINIMIZED]
autoimage
strip :WAT,Cl-,K+,Na+ outprefix stripped
trajout NPT_eq.stripped.pdb
EOF
cpptraj -i cpptraj.inp



